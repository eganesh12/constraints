#!/usr/bin/env python3
"""
Comparison Tool - Helps users choose between options by analyzing trade-offs
"""

import json
import argparse
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from enum import Enum

class ComparisonType(Enum):
    API = "api"
    CLOUD_SERVICE = "cloud_service"
    TECH_STACK = "tech_stack"
    FRAMEWORK = "framework"
    DATABASE = "database"
    GENERAL = "general"

@dataclass
class Criterion:
    name: str
    weight: float = 1.0
    description: str = ""

@dataclass
class Option:
    name: str
    description: str
    scores: Dict[str, float]  # criterion_name -> score (1-10)
    pros: List[str]
    cons: List[str]
    use_cases: List[str]
    cost_info: Optional[str] = None
    learning_curve: Optional[str] = None

@dataclass
class ComparisonResult:
    winner: str
    confidence: float
    reasoning: str
    detailed_scores: Dict[str, Dict[str, float]]

class ComparisonTool:
    def __init__(self):
        self.criteria = {}
        self.options = {}
        
    def add_criterion(self, name: str, weight: float = 1.0, description: str = ""):
        """Add a comparison criterion"""
        self.criteria[name] = Criterion(name, weight, description)
    
    def add_option(self, name: str, description: str, scores: Dict[str, float], 
                   pros: List[str], cons: List[str], use_cases: List[str],
                   cost_info: str = None, learning_curve: str = None):
        """Add an option to compare"""
        self.options[name] = Option(
            name, description, scores, pros, cons, use_cases, cost_info, learning_curve
        )
    
    def compare(self) -> ComparisonResult:
        """Perform weighted comparison and return results"""
        if len(self.options) < 2:
            raise ValueError("Need at least 2 options to compare")
        
        weighted_scores = {}
        detailed_scores = {}
        
        for option_name, option in self.options.items():
            total_score = 0
            max_possible = 0
            detailed_scores[option_name] = {}
            
            for criterion_name, criterion in self.criteria.items():
                if criterion_name in option.scores:
                    score = option.scores[criterion_name]
                    weighted_score = score * criterion.weight
                    total_score += weighted_score
                    max_possible += 10 * criterion.weight
                    detailed_scores[option_name][criterion_name] = score
            
            weighted_scores[option_name] = (total_score / max_possible) * 100 if max_possible > 0 else 0
        
        # Find winner
        winner = max(weighted_scores.keys(), key=lambda x: weighted_scores[x])
        winner_score = weighted_scores[winner]
        
        # Calculate confidence based on score gap
        scores_list = list(weighted_scores.values())
        scores_list.sort(reverse=True)
        confidence = (scores_list[0] - scores_list[1]) / 100 if len(scores_list) > 1 else 1.0
        
        # Generate reasoning
        reasoning = self._generate_reasoning(winner, weighted_scores, detailed_scores)
        
        return ComparisonResult(winner, confidence, reasoning, detailed_scores)
    
    def _generate_reasoning(self, winner: str, weighted_scores: Dict[str, float], 
                          detailed_scores: Dict[str, Dict[str, float]]) -> str:
        """Generate human-readable reasoning for the comparison"""
        reasoning = f"{winner} scored highest with {weighted_scores[winner]:.1f}%.\n\n"
        
        # Analyze strengths and weaknesses
        winner_option = self.options[winner]
        reasoning += f"Key strengths of {winner}:\n"
        for pro in winner_option.pros[:3]:  # Top 3 pros
            reasoning += f"• {pro}\n"
        
        reasoning += f"\nPotential concerns:\n"
        for con in winner_option.cons[:2]:  # Top 2 cons
            reasoning += f"• {con}\n"
        
        # Compare with runner-up
        sorted_options = sorted(weighted_scores.items(), key=lambda x: x[1], reverse=True)
        if len(sorted_options) > 1:
            runner_up = sorted_options[1][0]
            reasoning += f"\n{runner_up} was close behind ({sorted_options[1][1]:.1f}%). "
            reasoning += f"Consider {runner_up} if:\n"
            for use_case in self.options[runner_up].use_cases[:2]:
                reasoning += f"• {use_case}\n"
        
        return reasoning
    
    def generate_report(self) -> str:
        """Generate a comprehensive comparison report"""
        if not self.options:
            return "No options to compare"
        
        result = self.compare()
        
        report = "# Comparison Report\n\n"
        
        # Executive Summary
        report += "## Executive Summary\n"
        report += f"**Recommended Choice:** {result.winner}\n"
        report += f"**Confidence Level:** {result.confidence:.1%}\n\n"
        report += result.reasoning + "\n"
        
        # Detailed Breakdown
        report += "## Detailed Analysis\n\n"
        
        for option_name, option in self.options.items():
            report += f"### {option_name}\n"
            report += f"{option.description}\n\n"
            
            # Scores by criterion
            report += "**Scores:**\n"
            for criterion_name in self.criteria:
                if criterion_name in option.scores:
                    score = option.scores[criterion_name]
                    report += f"• {criterion_name}: {score}/10\n"
            
            report += f"\n**Pros:**\n"
            for pro in option.pros:
                report += f"• {pro}\n"
            
            report += f"\n**Cons:**\n"
            for con in option.cons:
                report += f"• {con}\n"
            
            report += f"\n**Best for:**\n"
            for use_case in option.use_cases:
                report += f"• {use_case}\n"
            
            if option.cost_info:
                report += f"\n**Cost:** {option.cost_info}\n"
            
            if option.learning_curve:
                report += f"**Learning Curve:** {option.learning_curve}\n"
            
            report += "\n---\n\n"
        
        # Criteria explanation
        report += "## Evaluation Criteria\n\n"
        for criterion in self.criteria.values():
            weight_indicator = "🔥" if criterion.weight > 1.5 else "⭐" if criterion.weight > 1.0 else "📝"
            report += f"**{criterion.name}** {weight_indicator}\n"
            if criterion.description:
                report += f"{criterion.description}\n"
            report += f"Weight: {criterion.weight}x\n\n"
        
        return report

def create_api_comparison():
    """Example: Compare REST vs GraphQL APIs"""
    tool = ComparisonTool()
    
    # Define criteria
    tool.add_criterion("ease_of_use", 1.5, "How easy is it to implement and use")
    tool.add_criterion("performance", 1.2, "Speed and efficiency")
    tool.add_criterion("flexibility", 1.0, "Adaptability to different use cases")
    tool.add_criterion("ecosystem", 1.0, "Available tools and community support")
    tool.add_criterion("learning_curve", 0.8, "Time to become productive")
    
    # Add options
    tool.add_option(
        "REST API",
        "Traditional HTTP-based API using standard methods (GET, POST, PUT, DELETE)",
        scores={
            "ease_of_use": 8,
            "performance": 7,
            "flexibility": 6,
            "ecosystem": 9,
            "learning_curve": 9
        },
        pros=[
            "Simple and well-understood",
            "Excellent caching support",
            "Wide tooling support",
            "Stateless and scalable"
        ],
        cons=[
            "Over-fetching and under-fetching data",
            "Multiple round trips needed",
            "Versioning challenges"
        ],
        use_cases=[
            "Simple CRUD operations",
            "Public APIs with broad compatibility needs",
            "Teams new to API development"
        ],
        cost_info="Low implementation cost",
        learning_curve="Easy - most developers familiar"
    )
    
    tool.add_option(
        "GraphQL",
        "Query language and runtime for APIs with flexible data fetching",
        scores={
            "ease_of_use": 6,
            "performance": 8,
            "flexibility": 9,
            "ecosystem": 7,
            "learning_curve": 5
        },
        pros=[
            "Single endpoint for all data needs",
            "Precise data fetching",
            "Strong type system",
            "Real-time subscriptions"
        ],
        cons=[
            "Steeper learning curve",
            "Caching complexity",
            "Query complexity analysis needed",
            "Potential for expensive queries"
        ],
        use_cases=[
            "Complex data relationships",
            "Mobile apps with bandwidth constraints",
            "Rapid frontend development"
        ],
        cost_info="Higher initial setup cost",
        learning_curve="Moderate - requires new concepts"
    )
    
    return tool

def create_cloud_comparison():
    """Example: Compare AWS vs Azure vs GCP"""
    tool = ComparisonTool()
    
    tool.add_criterion("cost", 1.5, "Pricing and cost optimization")
    tool.add_criterion("services", 1.2, "Breadth and depth of services")
    tool.add_criterion("ease_of_use", 1.0, "User interface and developer experience")
    tool.add_criterion("performance", 1.0, "Speed and reliability")
    tool.add_criterion("support", 0.8, "Documentation and customer support")
    
    tool.add_option(
        "AWS",
        "Amazon Web Services - the largest cloud provider",
        scores={"cost": 6, "services": 10, "ease_of_use": 6, "performance": 9, "support": 8},
        pros=["Most comprehensive service catalog", "Mature ecosystem", "Global presence"],
        cons=["Complex pricing", "Steep learning curve", "Can be expensive"],
        use_cases=["Enterprise applications", "Startups needing to scale", "Complex architectures"]
    )
    
    tool.add_option(
        "Azure",
        "Microsoft's cloud platform with strong enterprise integration",
        scores={"cost": 7, "services": 8, "ease_of_use": 7, "performance": 8, "support": 9},
        pros=["Great Windows/.NET integration", "Hybrid cloud strength", "Enterprise features"],
        cons=["Smaller service catalog than AWS", "Less mature in some areas"],
        use_cases=["Microsoft-centric organizations", "Hybrid cloud needs", "Enterprise Windows apps"]
    )
    
    tool.add_option(
        "GCP",
        "Google Cloud Platform with strength in data and AI",
        scores={"cost": 8, "services": 7, "ease_of_use": 8, "performance": 9, "support": 7},
        pros=["Competitive pricing", "Excellent data/AI services", "Clean UI", "Strong Kubernetes"],
        cons=["Smaller ecosystem", "Fewer enterprise features", "Less global presence"],
        use_cases=["Data analytics projects", "AI/ML workloads", "Kubernetes-native apps"]
    )
    
    return tool

def main():
    parser = argparse.ArgumentParser(description="Compare options and analyze trade-offs")
    parser.add_argument("--type", choices=[t.value for t in ComparisonType], 
                       default="general", help="Type of comparison")
    parser.add_argument("--example", choices=["api", "cloud"], 
                       help="Run a built-in example comparison")
    parser.add_argument("--output", choices=["report", "json"], default="report",
                       help="Output format")
    
    args = parser.parse_args()
    
    if args.example == "api":
        tool = create_api_comparison()
        print(tool.generate_report())
    elif args.example == "cloud":
        tool = create_cloud_comparison()
        print(tool.generate_report())
    else:
        print("Comparison Tool - Help users choose between options")
        print("\nAvailable examples:")
        print("  python comparison_tool.py --example api")
        print("  python comparison_tool.py --example cloud")
        print("\nFor custom comparisons, use the ComparisonTool class in your code.")

if __name__ == "__main__":
    main()