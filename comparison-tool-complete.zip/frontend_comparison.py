#!/usr/bin/env python3
"""
Frontend framework comparison example
"""

from comparison_tool import ComparisonTool

def create_frontend_comparison():
    """Compare React vs Vue vs Angular for web development"""
    tool = ComparisonTool()
    
    tool.add_criterion("learning_curve", 1.4, "Time to become productive")
    tool.add_criterion("performance", 1.2, "Runtime performance and bundle size")
    tool.add_criterion("ecosystem", 1.1, "Available libraries and tools")
    tool.add_criterion("developer_experience", 1.0, "Development tools and workflow")
    tool.add_criterion("job_market", 0.8, "Availability of developers and jobs")
    
    tool.add_option(
        "React",
        "JavaScript library for building user interfaces with component-based architecture",
        scores={
            "learning_curve": 7,
            "performance": 8,
            "ecosystem": 10,
            "developer_experience": 8,
            "job_market": 10
        },
        pros=[
            "Huge ecosystem and community",
            "Flexible and unopinionated",
            "Excellent developer tools",
            "Strong job market",
            "Backed by Meta"
        ],
        cons=[
            "Requires additional libraries for full functionality",
            "Frequent ecosystem changes",
            "JSX learning curve",
            "Decision fatigue from too many options"
        ],
        use_cases=[
            "Large-scale applications",
            "Teams wanting flexibility",
            "Projects requiring extensive third-party integrations",
            "Companies with React expertise"
        ],
        cost_info="Free and open-source",
        learning_curve="Moderate - JavaScript and JSX knowledge needed"
    )
    
    tool.add_option(
        "Vue.js",
        "Progressive JavaScript framework with gentle learning curve",
        scores={
            "learning_curve": 9,
            "performance": 9,
            "ecosystem": 7,
            "developer_experience": 9,
            "job_market": 6
        },
        pros=[
            "Gentle learning curve",
            "Excellent documentation",
            "Great performance out of the box",
            "Template syntax familiar to HTML developers",
            "Good balance of features and simplicity"
        ],
        cons=[
            "Smaller ecosystem than React",
            "Less job market demand",
            "Fewer large-scale enterprise adoptions",
            "Mainly maintained by one person (Evan You)"
        ],
        use_cases=[
            "Small to medium projects",
            "Teams new to modern frameworks",
            "Rapid prototyping",
            "Projects requiring quick development"
        ],
        cost_info="Free and open-source",
        learning_curve="Easy - HTML/CSS developers can start quickly"
    )
    
    tool.add_option(
        "Angular",
        "Full-featured TypeScript framework with opinionated architecture",
        scores={
            "learning_curve": 4,
            "performance": 7,
            "ecosystem": 8,
            "developer_experience": 7,
            "job_market": 8
        },
        pros=[
            "Complete framework with everything included",
            "Strong TypeScript integration",
            "Excellent for large enterprise applications",
            "Powerful CLI and tooling",
            "Backed by Google"
        ],
        cons=[
            "Steep learning curve",
            "Heavy and complex for simple projects",
            "Frequent major version updates",
            "Verbose syntax and concepts"
        ],
        use_cases=[
            "Large enterprise applications",
            "Teams with strong TypeScript background",
            "Projects requiring comprehensive features out of the box",
            "Long-term maintenance projects"
        ],
        cost_info="Free and open-source",
        learning_curve="Difficult - requires TypeScript and Angular concepts"
    )
    
    return tool

if __name__ == "__main__":
    print("=== Frontend Framework Comparison ===\n")
    
    frontend_tool = create_frontend_comparison()
    print(frontend_tool.generate_report())