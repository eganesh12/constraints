#!/usr/bin/env python3
"""
Run all comparison demos to showcase the tool's capabilities
"""

import os
import sys
from comparison_tool import ComparisonTool

def print_separator(title):
    """Print a nice separator with title"""
    print("\n" + "="*80)
    print(f"  {title}")
    print("="*80 + "\n")

def demo_api_comparison():
    """Demo API comparison"""
    print_separator("🔌 API ARCHITECTURE COMPARISON")
    
    tool = ComparisonTool()
    
    # Define criteria
    tool.add_criterion("ease_of_use", 1.5, "How easy is it to implement and use")
    tool.add_criterion("performance", 1.2, "Speed and efficiency")
    tool.add_criterion("flexibility", 1.0, "Adaptability to different use cases")
    tool.add_criterion("ecosystem", 1.0, "Available tools and community support")
    
    # Add REST API
    tool.add_option(
        "REST API",
        "Traditional HTTP-based API using standard methods",
        scores={"ease_of_use": 8, "performance": 7, "flexibility": 6, "ecosystem": 9},
        pros=["Simple and well-understood", "Excellent caching support", "Wide tooling support"],
        cons=["Over-fetching data", "Multiple round trips needed", "Versioning challenges"],
        use_cases=["Simple CRUD operations", "Public APIs", "Teams new to API development"]
    )
    
    # Add GraphQL
    tool.add_option(
        "GraphQL",
        "Query language and runtime for APIs with flexible data fetching",
        scores={"ease_of_use": 6, "performance": 8, "flexibility": 9, "ecosystem": 7},
        pros=["Single endpoint", "Precise data fetching", "Strong type system", "Real-time subscriptions"],
        cons=["Steeper learning curve", "Caching complexity", "Query complexity analysis needed"],
        use_cases=["Complex data relationships", "Mobile apps", "Rapid frontend development"]
    )
    
    result = tool.compare()
    print(f"🏆 WINNER: {result.winner}")
    print(f"📊 CONFIDENCE: {result.confidence:.1%}")
    print(f"💡 REASONING: {result.reasoning}")

def demo_database_comparison():
    """Demo database comparison"""
    print_separator("🗄️ DATABASE TECHNOLOGY COMPARISON")
    
    tool = ComparisonTool()
    
    # Define criteria
    tool.add_criterion("scalability", 1.3, "Ability to handle growing data and traffic")
    tool.add_criterion("consistency", 1.2, "ACID compliance and data integrity")
    tool.add_criterion("query_flexibility", 1.0, "Complex query capabilities")
    tool.add_criterion("performance", 1.1, "Speed for typical operations")
    
    # Add PostgreSQL
    tool.add_option(
        "PostgreSQL",
        "Advanced open-source relational database with JSON support",
        scores={"scalability": 7, "consistency": 10, "query_flexibility": 9, "performance": 8},
        pros=["ACID compliance", "Rich SQL features", "JSON/JSONB support", "Mature ecosystem"],
        cons=["Vertical scaling limitations", "More complex setup", "Can be overkill for simple cases"],
        use_cases=["ACID transactions", "Complex queries", "Financial systems"]
    )
    
    # Add MongoDB
    tool.add_option(
        "MongoDB",
        "Document-oriented NoSQL database with flexible schema",
        scores={"scalability": 9, "consistency": 6, "query_flexibility": 7, "performance": 8},
        pros=["Horizontal scaling", "Flexible schema", "Rich query language", "Good read performance"],
        cons=["Eventual consistency", "Memory usage", "Less mature transactions"],
        use_cases=["Rapid prototyping", "Content management", "Real-time analytics"]
    )
    
    # Add Redis
    tool.add_option(
        "Redis",
        "In-memory data structure store used as database, cache, and message broker",
        scores={"scalability": 8, "consistency": 7, "query_flexibility": 5, "performance": 10},
        pros=["Extremely fast", "Rich data structures", "Built-in pub/sub", "Simple to operate"],
        cons=["Limited by RAM", "Simple queries", "Persistence configuration", "Not primary DB"],
        use_cases=["Caching layer", "Session storage", "Real-time leaderboards"]
    )
    
    result = tool.compare()
    print(f"🏆 WINNER: {result.winner}")
    print(f"📊 CONFIDENCE: {result.confidence:.1%}")
    print(f"💡 REASONING: {result.reasoning}")

def demo_cloud_comparison():
    """Demo cloud provider comparison"""
    print_separator("☁️ CLOUD PROVIDER COMPARISON")
    
    tool = ComparisonTool()
    
    # Define criteria
    tool.add_criterion("cost", 1.5, "Pricing and cost optimization")
    tool.add_criterion("services", 1.2, "Breadth and depth of services")
    tool.add_criterion("ease_of_use", 1.0, "User interface and developer experience")
    tool.add_criterion("performance", 1.0, "Speed and reliability")
    
    # Add AWS
    tool.add_option(
        "AWS",
        "Amazon Web Services - the largest cloud provider",
        scores={"cost": 6, "services": 10, "ease_of_use": 6, "performance": 9},
        pros=["Most comprehensive services", "Mature ecosystem", "Global presence"],
        cons=["Complex pricing", "Steep learning curve", "Can be expensive"],
        use_cases=["Enterprise applications", "Startups scaling", "Complex architectures"]
    )
    
    # Add Azure
    tool.add_option(
        "Azure",
        "Microsoft's cloud platform with strong enterprise integration",
        scores={"cost": 7, "services": 8, "ease_of_use": 7, "performance": 8},
        pros=["Windows/.NET integration", "Hybrid cloud strength", "Enterprise features"],
        cons=["Smaller service catalog", "Less mature in some areas"],
        use_cases=["Microsoft-centric orgs", "Hybrid cloud", "Enterprise Windows apps"]
    )
    
    # Add GCP
    tool.add_option(
        "GCP",
        "Google Cloud Platform with strength in data and AI",
        scores={"cost": 8, "services": 7, "ease_of_use": 8, "performance": 9},
        pros=["Competitive pricing", "Excellent data/AI services", "Clean UI", "Strong Kubernetes"],
        cons=["Smaller ecosystem", "Fewer enterprise features", "Less global presence"],
        use_cases=["Data analytics", "AI/ML workloads", "Kubernetes-native apps"]
    )
    
    result = tool.compare()
    print(f"🏆 WINNER: {result.winner}")
    print(f"📊 CONFIDENCE: {result.confidence:.1%}")
    print(f"💡 REASONING: {result.reasoning}")

def demo_custom_comparison():
    """Demo custom comparison - Testing Frameworks"""
    print_separator("🧪 CUSTOM COMPARISON: TESTING FRAMEWORKS")
    
    tool = ComparisonTool()
    
    # Define criteria specific to testing
    tool.add_criterion("ease_of_setup", 1.5, "How quickly can we get started?")
    tool.add_criterion("performance", 1.3, "Test execution speed")
    tool.add_criterion("features", 1.2, "Built-in capabilities")
    tool.add_criterion("ecosystem", 1.0, "Community support")
    
    # Add Jest
    tool.add_option(
        "Jest",
        "JavaScript testing framework with zero configuration",
        scores={"ease_of_setup": 9, "performance": 6, "features": 9, "ecosystem": 10},
        pros=["Zero config", "Excellent mocking", "Snapshot testing", "Great React integration"],
        cons=["Can be slow", "Heavy bundle", "Memory issues"],
        use_cases=["React apps", "Node.js projects", "Quick setup needed"]
    )
    
    # Add Vitest
    tool.add_option(
        "Vitest",
        "Fast unit testing framework powered by Vite",
        scores={"ease_of_setup": 8, "performance": 10, "features": 8, "ecosystem": 6},
        pros=["Extremely fast", "ES modules support", "HMR for tests", "Jest-compatible"],
        cons=["Newer ecosystem", "Less mature tooling", "Smaller community"],
        use_cases=["Vite projects", "Performance-critical testing", "Modern JS/TS"]
    )
    
    result = tool.compare()
    print(f"🏆 WINNER: {result.winner}")
    print(f"📊 CONFIDENCE: {result.confidence:.1%}")
    print(f"💡 REASONING: {result.reasoning}")

def show_tool_benefits():
    """Show the key benefits of using this comparison tool"""
    print_separator("✨ WHY USE THIS COMPARISON TOOL?")
    
    benefits = [
        "🎯 TRADE-OFF FOCUSED: Shows what you gain/lose with each choice",
        "⚖️ WEIGHTED DECISIONS: Prioritize what matters most for YOUR situation",
        "📊 CONFIDENCE LEVELS: Know how clear-cut the decision really is",
        "🔍 STRUCTURED THINKING: Forces consideration of multiple factors",
        "📝 DOCUMENTED REASONING: Keep track of why decisions were made",
        "🔧 HIGHLY CUSTOMIZABLE: Add your own criteria and options",
        "🚀 REAL-WORLD EXAMPLES: Covers common developer decisions",
        "💡 CONTEXT-AWARE: Different weights for different scenarios"
    ]
    
    for benefit in benefits:
        print(f"  {benefit}")
    
    print(f"\n💭 PHILOSOPHY:")
    print(f"  Instead of asking 'What's the best X?'")
    print(f"  Ask 'What's the best X for MY team, timeline, and requirements?'")
    print(f"  This tool helps structure that more nuanced analysis.")

def main():
    """Run all demos"""
    print("🤔 COMPARISON TOOL DEMONSTRATION")
    print("Helping developers make better decisions through trade-off analysis")
    
    # Show tool benefits first
    show_tool_benefits()
    
    # Run all comparison demos
    demo_api_comparison()
    demo_database_comparison()
    demo_cloud_comparison()
    demo_custom_comparison()
    
    # Final summary
    print_separator("🎉 DEMO COMPLETE")
    print("All comparisons completed successfully!")
    print("\nNext steps:")
    print("1. 📖 Read README.md for detailed usage instructions")
    print("2. 🌐 Open web_interface.html for interactive demos")
    print("3. 🛠️ Create your own comparisons using the ComparisonTool class")
    print("4. 📚 Check USAGE_GUIDE.md for advanced patterns and best practices")
    
    print(f"\n💡 Pro tip: Run individual examples with:")
    print(f"   python comparison_tool.py --example api")
    print(f"   python comparison_tool.py --example cloud")
    print(f"   python database_comparison.py")
    print(f"   python frontend_comparison.py")

if __name__ == "__main__":
    main()