#!/usr/bin/env python3
"""
Database comparison example using the comparison tool
"""

from comparison_tool import ComparisonTool

def create_database_comparison():
    """Compare PostgreSQL vs MongoDB vs Redis for different use cases"""
    tool = ComparisonTool()
    
    # Criteria weighted by importance
    tool.add_criterion("scalability", 1.3, "Ability to handle growing data and traffic")
    tool.add_criterion("consistency", 1.2, "ACID compliance and data integrity")
    tool.add_criterion("query_flexibility", 1.0, "Complex query capabilities")
    tool.add_criterion("performance", 1.1, "Speed for typical operations")
    tool.add_criterion("operational_complexity", 0.9, "Ease of deployment and maintenance")
    
    tool.add_option(
        "PostgreSQL",
        "Advanced open-source relational database with JSON support",
        scores={
            "scalability": 7,
            "consistency": 10,
            "query_flexibility": 9,
            "performance": 8,
            "operational_complexity": 7
        },
        pros=[
            "ACID compliance and strong consistency",
            "Rich SQL features and extensions",
            "JSON/JSONB support for semi-structured data",
            "Mature ecosystem and tooling"
        ],
        cons=[
            "Vertical scaling limitations",
            "More complex setup than NoSQL",
            "Can be overkill for simple use cases"
        ],
        use_cases=[
            "Applications requiring ACID transactions",
            "Complex analytical queries",
            "Financial or healthcare systems",
            "Applications with structured data relationships"
        ],
        cost_info="Free open-source, managed services available",
        learning_curve="Moderate - SQL knowledge required"
    )
    
    tool.add_option(
        "MongoDB",
        "Document-oriented NoSQL database with flexible schema",
        scores={
            "scalability": 9,
            "consistency": 6,
            "query_flexibility": 7,
            "performance": 8,
            "operational_complexity": 8
        },
        pros=[
            "Horizontal scaling built-in",
            "Flexible schema for rapid development",
            "Rich query language for documents",
            "Good performance for read-heavy workloads"
        ],
        cons=[
            "Eventual consistency by default",
            "Memory usage can be high",
            "Less mature for complex transactions",
            "Query optimization can be tricky"
        ],
        use_cases=[
            "Rapid prototyping and development",
            "Content management systems",
            "Real-time analytics",
            "Applications with evolving data models"
        ],
        cost_info="Free community edition, paid Atlas cloud service",
        learning_curve="Easy - JSON-like documents"
    )
    
    tool.add_option(
        "Redis",
        "In-memory data structure store used as database, cache, and message broker",
        scores={
            "scalability": 8,
            "consistency": 7,
            "query_flexibility": 5,
            "performance": 10,
            "operational_complexity": 9
        },
        pros=[
            "Extremely fast in-memory operations",
            "Rich data structures (lists, sets, hashes)",
            "Built-in pub/sub messaging",
            "Simple to deploy and operate"
        ],
        cons=[
            "Limited by available RAM",
            "Simple query capabilities",
            "Data persistence requires configuration",
            "Not suitable as primary database for most apps"
        ],
        use_cases=[
            "Caching layer",
            "Session storage",
            "Real-time leaderboards",
            "Message queuing",
            "Rate limiting"
        ],
        cost_info="Free open-source, managed Redis Cloud available",
        learning_curve="Easy - simple key-value concepts"
    )
    
    return tool

if __name__ == "__main__":
    print("=== Database Technology Comparison ===\n")
    
    db_tool = create_database_comparison()
    print(db_tool.generate_report())