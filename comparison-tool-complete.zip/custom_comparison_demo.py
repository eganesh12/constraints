#!/usr/bin/env python3
"""
Custom comparison examples showing the flexibility of the tool
"""

from comparison_tool import ComparisonTool

def compare_testing_frameworks():
    """Example: Compare Jest vs Vitest vs Cypress"""
    print("=== Testing Framework Comparison ===\n")
    
    tool = ComparisonTool()
    
    # Define criteria specific to testing frameworks
    tool.add_criterion("ease_of_setup", 1.5, "How quickly can we get started?")
    tool.add_criterion("performance", 1.3, "Test execution speed")
    tool.add_criterion("features", 1.2, "Built-in capabilities and assertions")
    tool.add_criterion("ecosystem", 1.0, "Community and plugin support")
    tool.add_criterion("debugging", 1.1, "Debugging and error reporting quality")
    
    tool.add_option(
        "Jest",
        "JavaScript testing framework with zero configuration",
        scores={
            "ease_of_setup": 9,
            "performance": 6,
            "features": 9,
            "ecosystem": 10,
            "debugging": 8
        },
        pros=[
            "Zero configuration required",
            "Excellent mocking capabilities",
            "Snapshot testing built-in",
            "Great React integration",
            "Huge community and ecosystem"
        ],
        cons=[
            "Can be slow on large codebases",
            "Heavy bundle size",
            "Memory usage issues",
            "Complex configuration for advanced use cases"
        ],
        use_cases=[
            "React applications",
            "Node.js projects",
            "Teams wanting quick setup",
            "Projects needing comprehensive testing features"
        ],
        cost_info="Free and open-source",
        learning_curve="Easy for JavaScript developers"
    )
    
    tool.add_option(
        "Vitest",
        "Fast unit testing framework powered by Vite",
        scores={
            "ease_of_setup": 8,
            "performance": 10,
            "features": 8,
            "ecosystem": 6,
            "debugging": 9
        },
        pros=[
            "Extremely fast execution",
            "Native ES modules support",
            "Hot module replacement for tests",
            "Jest-compatible API",
            "Excellent TypeScript support"
        ],
        cons=[
            "Newer ecosystem",
            "Less mature tooling",
            "Smaller community",
            "Limited browser testing capabilities"
        ],
        use_cases=[
            "Vite-based projects",
            "Performance-critical testing",
            "Modern JavaScript/TypeScript projects",
            "Teams prioritizing speed"
        ],
        cost_info="Free and open-source",
        learning_curve="Easy if familiar with Jest"
    )
    
    tool.add_option(
        "Cypress",
        "End-to-end testing framework for web applications",
        scores={
            "ease_of_setup": 7,
            "performance": 5,
            "features": 10,
            "ecosystem": 8,
            "debugging": 10
        },
        pros=[
            "Excellent debugging experience",
            "Real browser testing",
            "Time-travel debugging",
            "Great documentation",
            "Visual test runner"
        ],
        cons=[
            "Slower than unit tests",
            "Can be flaky",
            "Limited to Chromium browsers (free version)",
            "Requires more maintenance"
        ],
        use_cases=[
            "End-to-end testing",
            "Integration testing",
            "User journey validation",
            "Teams needing visual feedback"
        ],
        cost_info="Free for basic use, paid for advanced features",
        learning_curve="Moderate - different paradigm from unit testing"
    )
    
    return tool

def compare_deployment_platforms():
    """Example: Compare Vercel vs Netlify vs AWS vs Self-hosted"""
    print("=== Deployment Platform Comparison ===\n")
    
    tool = ComparisonTool()
    
    # Criteria for deployment platforms
    tool.add_criterion("ease_of_deployment", 1.6, "How simple is it to deploy?")
    tool.add_criterion("cost", 1.4, "Pricing for typical usage")
    tool.add_criterion("performance", 1.2, "Speed and global distribution")
    tool.add_criterion("features", 1.0, "Built-in capabilities")
    tool.add_criterion("vendor_lock_in", 0.8, "How easy is it to migrate away?")
    
    tool.add_option(
        "Vercel",
        "Frontend-focused platform with excellent Next.js integration",
        scores={
            "ease_of_deployment": 10,
            "cost": 7,
            "performance": 9,
            "features": 9,
            "vendor_lock_in": 6
        },
        pros=[
            "Zero-config deployments",
            "Excellent Next.js integration",
            "Global CDN included",
            "Preview deployments",
            "Great developer experience"
        ],
        cons=[
            "Can get expensive at scale",
            "Primarily focused on frontend",
            "Limited backend capabilities",
            "Vendor lock-in concerns"
        ],
        use_cases=[
            "Next.js applications",
            "Static sites",
            "Frontend-heavy projects",
            "Teams wanting simplicity"
        ],
        cost_info="Free tier available, usage-based pricing",
        learning_curve="Very easy"
    )
    
    tool.add_option(
        "Netlify",
        "JAMstack platform with strong static site capabilities",
        scores={
            "ease_of_deployment": 9,
            "cost": 8,
            "performance": 8,
            "features": 8,
            "vendor_lock_in": 7
        },
        pros=[
            "Great for static sites",
            "Built-in form handling",
            "Branch deployments",
            "Good free tier",
            "Strong community"
        ],
        cons=[
            "Limited dynamic capabilities",
            "Function limitations",
            "Less suitable for complex apps",
            "Build time restrictions"
        ],
        use_cases=[
            "Static websites",
            "JAMstack applications",
            "Documentation sites",
            "Small to medium projects"
        ],
        cost_info="Generous free tier, reasonable paid plans",
        learning_curve="Easy"
    )
    
    tool.add_option(
        "AWS",
        "Comprehensive cloud platform with full control",
        scores={
            "ease_of_deployment": 4,
            "cost": 6,
            "performance": 10,
            "features": 10,
            "vendor_lock_in": 5
        },
        pros=[
            "Complete control and flexibility",
            "Unlimited scalability",
            "Comprehensive service catalog",
            "Global infrastructure",
            "Enterprise-grade security"
        ],
        cons=[
            "Complex setup and configuration",
            "Steep learning curve",
            "Can be expensive without optimization",
            "Overwhelming number of options"
        ],
        use_cases=[
            "Enterprise applications",
            "Complex architectures",
            "High-scale applications",
            "Teams with DevOps expertise"
        ],
        cost_info="Pay-as-you-go, can be optimized for cost",
        learning_curve="Difficult - requires cloud expertise"
    )
    
    return tool

if __name__ == "__main__":
    # Run testing framework comparison
    testing_tool = compare_testing_frameworks()
    print(testing_tool.generate_report())
    
    print("\n" + "="*60 + "\n")
    
    # Run deployment platform comparison
    deployment_tool = compare_deployment_platforms()
    print(deployment_tool.generate_report())